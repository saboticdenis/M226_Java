import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Driver.
 * 
 * @author DSabotic 
 * @version V0.1
 */
public class Driver extends Actor
{
    /**
     * Mit jedem Act befehl bewegt sich der Driver 4 Schritte nach vorne
     * 
     */
    public void act() 
    {
        setLocation(getX()-4, getY());
        checkCollision();
        
         if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }   
    
        private void checkCollision()
    {
        if (isTouching(Ghostdriver.class))
        {
            removeTouching(Ghostdriver.class);
            Greenfoot.stop();
            setImage("boom.png");
        }
    
    }
}
